package com.noiid.githubusers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.noiid.githubusers.dataclass.Account

class DetailAccountActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ACCOUNT = "extra_account"
    }
    private lateinit var tvFollower: TextView
    private lateinit var tvFollowing: TextView
    private lateinit var tvName: TextView
    private lateinit var tvCompany: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvRepo: TextView
    private lateinit var imgAccount: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_account)

        val account = intent.getParcelableExtra<Account>(EXTRA_ACCOUNT) as Account
        supportActionBar?.title = "Detail User @"+account.username.toString()

        tvFollower = findViewById(R.id.tvFollowers)
        tvFollowing = findViewById(R.id.tvFollowing)
        imgAccount = findViewById(R.id.imageAccount)
        tvName = findViewById(R.id.tvName)
        tvCompany = findViewById(R.id.tvCompany)
        tvLocation = findViewById(R.id.tvLocation)
        tvRepo = findViewById(R.id.tvRepo)

        tvFollower.text = " " + account.follower + " followers"
        tvFollowing.text = " "+ account.following + " following"
        tvName.text = account.name
        tvCompany.text = account.company
        tvLocation.text = account.location
        tvRepo.text = " "+ account.repository + " repositories"

        Glide.with(this.applicationContext)
            .load(account.avatar)
            .circleCrop()
            .into(this.imgAccount)

    }
}