package com.noiid.githubusers

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.noiid.githubusers.adapter.ListAccountAdapter
import com.noiid.githubusers.dataclass.Account
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var rvAccount: RecyclerView
    private val list = ArrayList<Account>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.title = "Users Github"
        rvAccount = findViewById(R.id.rv_account)
        rvAccount.setHasFixedSize(true)

        list.addAll(listAccount)
        showRecyclerList()
    }

    private val listAccount: ArrayList<Account>
        get(){
            val dataName = resources.getStringArray(R.array.data_name)
            val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
            val dataUsername = resources.getStringArray(R.array.data_username)
            val dataLocation = resources.getStringArray(R.array.data_location)
            val dataCompany = resources.getStringArray(R.array.data_company)
            val dataFollower = resources.getIntArray(R.array.data_followers)
            val dataFollowing = resources.getIntArray(R.array.data_following)
            val dataRepo = resources.getIntArray(R.array.data_repository)
            val listAccount = ArrayList<Account>()
            for (i in dataName.indices){
                val account = Account(dataUsername[i], dataName[i], dataPhoto.getResourceId(i, -1),dataLocation[i],dataCompany[i],dataRepo[i],dataFollower[i],dataFollowing[i])
                listAccount.add(account)
            }

            return listAccount
        }

    private fun showRecyclerList(){
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rvAccount.layoutManager = GridLayoutManager(this, 2)
        } else {
            rvAccount.layoutManager = LinearLayoutManager(this)
        }
        var listAccountAdapter = ListAccountAdapter(list)
        rvAccount.adapter = listAccountAdapter
        listAccountAdapter.setOnItemClickCallback(object : ListAccountAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Account) {
                showSelectedAccount(data)
            }
        })
    }

    private fun showSelectedAccount(account: Account) {
        val moveWithObjectIntent = Intent(this@MainActivity, DetailAccountActivity::class.java)
        moveWithObjectIntent.putExtra(DetailAccountActivity.EXTRA_ACCOUNT, account)
        startActivity(moveWithObjectIntent)
    }
}